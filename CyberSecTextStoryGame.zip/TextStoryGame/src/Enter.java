import java.util.Scanner;

public class Enter {

	public static void EnterKey() {
		@SuppressWarnings("resource")
		Scanner enter = new Scanner(System.in);
		String ent = enter.nextLine();
	}

}
